﻿namespace Employee_DataBase;

class Employee
{
    public int Age { get; set; }
    public string Position { get; set; }
    public string Surname { get; set; }
    public string Name { get; set; }

    public void ReadInfo()
    {
        Console.WriteLine($"Age:{Age} " + $"Position:{Position} " + $"Surname:{Surname} " + $"Name:{Name}");
    }

    
    public void AddAge()
    {
            bool IsWorking = true;
            do
            {
                Console.WriteLine("Enter your age :");
                try
                {
                    int age1 = int.Parse(Console.ReadLine());
                    Age = age1;
                    IsWorking = false;
                }
                catch (InvalidCastException ex)
                {
                    Console.WriteLine("Invalid input || try again");
                }
            } while (IsWorking == true);
    }

    public void AddPosition()
    {
       Console.WriteLine("Enter your position");
       string position = Console.ReadLine();
       this.Position = position;
    }
}