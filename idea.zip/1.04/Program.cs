﻿
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Employee_DataBase
{
    class Programm
    {
        static void Main(string[] args)
        {
            Employee employee = new Employee();
            while (true) {
                bool IsWorking;
                Console.WriteLine(
                    "Tell what do you want me to add/do : \n 1.Age \n 2.Position \n 3.Surname \n 4.Name \n 5.Read");
                var answer = Console.ReadLine();
                if (answer == "Age")
                { 
                    employee.AddAge();
                } 
                if (answer == "Read")
                {
                    employee.ReadInfo();
                }
            }
        }
    }
}
