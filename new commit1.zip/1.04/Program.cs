﻿
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Employee_DataBase
{
    class Programm
    {
        static void Main(string[] args)
        {
            int age = 0;
            bool IsWorking1 = true;
            ChangeInfo:
            do
            {
                try
                {
                    Console.Write("What`s your age: ");
                    int age1 = int.Parse(Console.ReadLine());
                    age = age1;
                    IsWorking1 = false;
                }
                catch
                {
                    Console.WriteLine("Invalid input || Try again");
                }
            } while (IsWorking1 != false);

            Console.Write("What`s your name: ");
            string name = Console.ReadLine();
            Console.Write("What`s your surname: ");
            string surname = Console.ReadLine();
            Console.Write("What`s your position: ");
            string position = Console.ReadLine();

            Employee employee = new Employee(age,position,surname,name);
            
            
            do
            {
                Console.WriteLine();
                Console.WriteLine("Possible actions ( type number ) : ");
                Console.WriteLine("1 - Exit");
                Console.WriteLine("2 - Change Information");
                Console.WriteLine("3 - Read information");
                Console.Write(">");
                var answer = Console.ReadLine();
                
                switch (answer)
                {
                    case "1":
                        Console.WriteLine("Goodbye! || See you soon");
                        Environment.Exit(0);
                        break;
                    case "2":
                        goto ChangeInfo;
                    case "3":
                        DataBase.ReadInfo(employee);
                        break;
                }
            } while (true);
            
            
        }
    }
}
