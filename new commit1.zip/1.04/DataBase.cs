﻿namespace Employee_DataBase;

public class DataBase
{
    public static void ReadInfo (Employee employee)
    {
        Console.WriteLine($"Age:{employee.Age} | " + $"Name: {employee.Name} | " + $"Surname: {employee.Surname} | " + $"Position: {employee.Position}" );
    }
}